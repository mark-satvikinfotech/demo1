<?php

namespace Infusionsoft;

class InfusionsoftException extends \Exception
{

}