<?php

 $config_log_file_name = TIMETAP_DIR.'log/IS_Emailhistory/config.txt';

 define('CONTACT_EMAILHISTORY_CRON_FILE_NAME', TIMETAP_DIR.'log/IS_Emailhistory/'.date('Y-m-d',time()).'.txt');
 


?>