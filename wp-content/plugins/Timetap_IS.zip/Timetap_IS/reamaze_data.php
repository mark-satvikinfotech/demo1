<?php
class Reamaze_data
{
	public function __construct()
	{
		
		/*if(isset($_REQUEST['Reamazecron']))
		{
			$Reamazecron = $_REQUEST['Reamazecron']; 
			if(strcasecmp($Reamazecron, "Y") == 0)
			{
			  include_once('reamaze_cron.php');
			}
		}
		if(isset($_REQUEST['ReamazeMessagecron']))
		{
			echo "Helo";
			$ReamazeMessagecron = $_REQUEST['ReamazeMessagecron']; 
			if(strcasecmp($ReamazeMessagecron, "Y") == 0)
			{
			  include_once('reamaze_textconversationcron.php');
			}
		}*/
	}
	function get_contacts($current_page)
	{
        $curlSession = curl_init('https://Infusionsoft.reamaze.io/api/v1/contacts?=&sort=date&page='.$current_page);

		curl_setopt($curlSession, CURLOPT_HEADER, false);
		curl_setopt($curlSession,CURLOPT_USERPWD,implode(':', array('pieter@pieterkdevilliers.co.uk', '60eb0ada86180343044e0ced9b6dfcd43388249a560faef1ba6d37bd36d0b71e'))
	    );
		
							
		curl_setopt($curlSession, CURLOPT_TIMEOUT, 30);
		curl_setopt($curlSession, CURLOPT_RETURNTRANSFER, true);
		$response = curl_exec($curlSession);
		
		$err = curl_error($curlSession);

		curl_close($curlSession);

		if ($err) 
		{
		  $response = $err;
		} 

		return $response;
				 
	}
	
	function writeToLog($file,$string)
	{
		
    	$open = fopen( $file, "a" ); 
    	$write = fputs( $open, $string); 
    	fclose( $open );
	}
	function update_LogFile($upd_data, $data_value, $config_log_file_name)
    {
        $config = json_decode(file_get_contents($config_log_file_name),true);    
        
        foreach($config as $key => $val)
        {    
            if($key == $upd_data)
            {
                $config[$key] = $data_value;
            }        
        }    
        file_put_contents($config_log_file_name, '');
        $config = json_encode($config);
        $this->writeToLog($config_log_file_name, $config."\n");        
    }
}
$obj = new Reamaze_data();
?>