<?php
    function getphoneno($contact_id,$tagx,$tagy)
	{
		include('infusion_config.php');
		$contactId=$contact_id;
		//echo $contactId;
		$selectedFields=array('Phone1');			
		$phone=$infusionsoft->contacts('xml')->load($contactId, $selectedFields);
		$phone = $phone['Phone1'];
		$phone = preg_replace("/[^0-9]/", "", $phone);
        $phone = substr($phone, -10);

		//retrive contacts from is using phone no
		$table = "Contact";
		$limit = 1000;
		$page = 0;
		$queryData = array('_CustomPhone'=>'%'.$phone,'Id'=>'~<>~'.$contact_id);
		$selectedFields = array('Id','FirstName','LastName','Company','JobTitle','Email','Phone1','ContactType','LeadSourceId','OwnerID','StreetAddress1','StreetAddress2','City','State','PostalCode','ZipFour1','Country','Phone1Type','Phone1','Phone1Ext','Phone2Type','Phone2','Phone2Ext','Fax1Type','Fax1','Website','Language','TimeZone','_CustomPhone','_ContactId','_Data','_FriendlyName','_LastUpadated','_Reamazemessage');
		$orderBy = "Id";
		$ascending = false;
		$data_contact=$infusionsoft->data('xml')->query($table, $limit, $page, $queryData, $selectedFields, $orderBy, $ascending);
		//echo "<pre>";
		//print_r($data_contact);


		$contact_data = array();

		 if (!empty($data_contact)){

			foreach ($data_contact as $result_contact)
			{
	            if($result_contact['Id'] != $contactId)
	            {
	            	$contact_ID=$result_contact['Id']; 

		            $data=$infusionsoft->contacts('xml')->merge($contactId, $contact_ID);
					//echo "<pre>";
					//print_r($data);
	            }
			}

		}
		else
		{
            $tag=$infusionsoft->contacts('xml')->addToGroup($contactId,$tagy);
			$infusionsoft->contacts('xml')->removeFromGroup($contactId,$tagx);
		}
		
	}


